//
//  ViewController.swift
//  Restaurant
//
//  Created by Lavpreet Kaur on 2017-11-01.
//  Copyright © 2017 Lavpreet. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate{

    @IBOutlet weak var pass: UITextField!
    @IBOutlet weak var uname: UITextField!
   
    @IBAction func login(_ sender: UIButton) {
        if(uname.text! == "" || pass.text! == ""){
            let alert = UIAlertController(title: "Message", message: "All fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            var u=MyMain.uname
            var p=MyMain.pass
            var status="0"
            var myindex=0
            for i in 0..<u.count{
                if(u[i]==uname.text!){
                    status="1"
                    myindex=Int(i)
                }
            }
            if(status=="1"){
                if(p[myindex]==pass.text!){
                    let ind=String(myindex)
                    MyMain.index=ind
                    let userhome:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "manager") as? ManagerViewController)!
                    self.navigationController?.pushViewController(userhome, animated: true)
                }else{
                    let alert = UIAlertController(title: "Oops!", message: "Wrong password", preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                let alert = UIAlertController(title: "Oops!", message: "Username is incorrect", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "res.jpg")!)
        // Do any additional setup after loading the view, typically from a nib.
        if(MyMain.mylogstataus==0){
            MyMain.uname=["pun","lav"]
            MyMain.pass=["123","123"]
            MyMain.name=["Puneet","Lavpreet"]
            MyMain.mob=["9876543211","9988776655"]
            MyMain.item=["Samosa","Pizza","Chana Bhatura","Daal Makhani","Spring Rolls"]
            MyMain.priceitem=["8","20","5","12","7"]
            
            MyMain.mylogstataus=1
        }
        self.uname.delegate=self
        self.pass.delegate=self
        MyMain.index=""
        navigationItem.hidesBackButton = true 
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

