//
//  EmployeeInfo.swift
//  Restaurant
//
//  Created by Lavpreet Kaur on 2017-11-09.
//  Copyright © 2017 Lavpreet. All rights reserved.
//

import UIKit

class EmployeeInfo: UIViewController, UIPickerViewDataSource,UIPickerViewDelegate , UITextFieldDelegate ,UITextViewDelegate{

    @IBOutlet weak var addr: UITextView!
    @IBOutlet weak var mob: UITextField!

    @IBOutlet weak var etype: UITextField!
    @IBOutlet weak var ename: UITextField!

    var menu=["Selet Type","Team Member","Delivery Person"]
    var gmenu=["Select Gender","Male","Female"]
     var buttonClickId = 0
    @IBOutlet weak var selectorUIView: UIView!
    
    @IBOutlet weak var genderButton: UIButton!
    
    @IBOutlet weak var genderdrop: UIPickerView!
    
    @IBOutlet weak var userTypeButton: UIButton!
    @IBOutlet weak var dropdown: UIPickerView!
    
    
    @IBAction func genderButton(_ sender: UIButton) {
        buttonClickId = 1;
        self.selectorUIView.isHidden = false;
        self.genderdrop.isHidden = false;
        self.dropdown.isHidden = true;
    }
    @IBAction func doneBtnA(_ sender: UIButton) {
        if(buttonClickId == 1){
            if(genderButton.titleLabel?.text == gmenu[0]){
                let alert = UIAlertController(title: "Error Message", message: "Please select gender first", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                return;
            }
        }else{
            if(userTypeButton.titleLabel?.text == gmenu[0]){
                let alert = UIAlertController(title: "Error Message", message: "Please select gender first", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                return;
            }
        }
        self.selectorUIView.isHidden = true;
        
    }
    
    
    @IBAction func typeButton(_ sender: UIButton) {
        buttonClickId = 2;
        self.selectorUIView.isHidden = false;
        self.genderdrop.isHidden = true;
        self.dropdown.isHidden = false;
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    @objc func hideKeyboardOnClick(_ sender: UITapGestureRecognizer) {
        self.view.endEditing(true);
    }
    
    
    
    
    @IBAction func addEmp(_ sender: UIButton) {
       
        if(ename.text!=="" || etype.text!=="" || genderButton.titleLabel?.text!==gmenu[0] || userTypeButton.titleLabel?.text!==menu[0] || mob.text!=="" || addr.text!==""){
            let alert = UIAlertController(title: "Alert!!", message: "Please enter the data", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
                MyMain.ename.append(ename.text!)
                MyMain.euname.append(etype.text!)
            MyMain.etype.append((userTypeButton.titleLabel?.text)!)
            MyMain.egender.append((genderButton.titleLabel?.text)!)
                MyMain.emob.append(mob.text!)
                MyMain.eaddr.append(addr.text!)
            let alert = UIAlertController(title: "Message", message: "New Employee Added", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            ename.text!=""
            etype.text!=""
            genderButton.setTitle(gmenu[0], for: .normal);
            userTypeButton.setTitle(menu[0], for: .normal);
            
            mob.text!=""
            addr.text!=""
            
        }
    
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("hey")
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "res.jpeg")!)
        self.userTypeButton.layer.cornerRadius = 6.0;
        self.userTypeButton.layer.borderColor = UIColor.lightGray.cgColor;
        self.userTypeButton.layer.borderWidth = 0.5;
        
        self.genderButton.layer.cornerRadius = 6.0;
        self.genderButton.layer.borderColor = UIColor.lightGray.cgColor;
        self.genderButton.layer.borderWidth = 0.5;
        
        self.ename.delegate=self
        self.mob.delegate=self
        self.addr.delegate=self
        self.etype.delegate=self
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.hideKeyboardOnClick(_:)))
        self.view.addGestureRecognizer(tapGesture);
        
    
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        
        if(pickerView==dropdown){
            return menu.count
        }else if(pickerView==genderdrop){
            return gmenu.count
        }
        return 1
    }
   
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if(pickerView==dropdown){
            return menu[row]
        }else if(pickerView==genderdrop){
            return gmenu[row]
        }
        return ""
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if(pickerView==dropdown){
            self.userTypeButton.setTitle(menu[row], for: .normal);
        }else if(pickerView==genderdrop){
            self.genderButton.setTitle(gmenu[row], for: .normal);
        }
        
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return true;
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
    }
    
}
