//
//  PaymentMethod.swift
//  Restaurant
//
//  Created by Lavpreet Kaur on 2017-11-09.
//  Copyright © 2017 Lavpreet. All rights reserved.
//

import UIKit

class PaymentMethod: UIViewController {
    func getDone(){
        MyMain.check=1
        let userhome:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "manager") as? ManagerViewController)!
        self.navigationController?.pushViewController(userhome, animated: true)
    }

    @IBAction func american(_ sender: UIButton) {
        getDone()
    }
    @IBAction func debit(_ sender: UIButton) {
        getDone()
    }
    @IBAction func master(_ sender: UIButton) {
        getDone()
    }
    @IBAction func cash(_ sender: UIButton) {
        getDone()
    }
    @IBAction func visa(_ sender: UIButton) {
        getDone()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
 self.view.backgroundColor = UIColor(patternImage: UIImage(named: "res.jpg")!)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
