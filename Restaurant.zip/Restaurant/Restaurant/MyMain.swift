//
//  File.swift
//  MobileStoreApplicstion
//
//  Created by Lavpreet Kaur on 2017-11-08.
//  Copyright © 2017 Lavpreet Kaur. All rights reserved.
//

import Foundation
class MyMain{
    
    static var uname=[String]()
    static var pass=[String]()
    static var mob=[String]()
    static var name=[String]()
    
    static var ename=[String]()
    static var euname=[String]()
    static var etype=[String]()
    static var egender=[String]()
    static var emob=[String]()
    static var eaddr=[String]()
    static var index=""
    
    static var item=[String]()
    static var priceitem=[String]()
    
    static var status=0
    static var mylogstataus=0
    static var city=""
    static var loc=""
    static var phone=[String]()
    static var price=[Int]()
    
    static var myorder=[String]()
    static var myOrderPrice=[String]()
    static var check=0
    
}

