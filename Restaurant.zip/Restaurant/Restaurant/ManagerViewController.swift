//
//  ManagerViewController.swift
//  Restaurant
//
//  Created by Lavpreet Kaur on 2017-11-09.
//  Copyright © 2017 Lavpreet. All rights reserved.
//

import UIKit

class ManagerViewController: UIViewController {

    @IBAction func logout(_ sender: UIButton) {
        let userhome:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "viewc") as? ViewController)!
        self.navigationController?.pushViewController(userhome, animated: true)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "res.jpg")!)
        if(MyMain.check==1){
            let alert = UIAlertController(title: "Message", message: "Order Placed", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
          
        }
        MyMain.check=0
        MyMain.myorder=[String]()
        MyMain.myOrderPrice=[String]()
        navigationItem.hidesBackButton = true 
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
