//
//  ChangePassword.swift
//  Restaurant
//
//  Created by Lavpreet Kaur on 2017-11-09.
//  Copyright © 2017 Lavpreet. All rights reserved.
//

import UIKit

class ChangePassword: UIViewController {

    @IBOutlet weak var confp: UITextField!
    @IBOutlet weak var newp: UITextField!
    @IBOutlet weak var old: UITextField!
   
    @IBAction func confirm(_ sender: UIButton) {
        var n=newp.text!
        var c=confp.text!
        if(old.text!=="" || newp.text!=="" || confp.text!==""){
            let alert = UIAlertController(title: "Alert!!", message: "Please enter data", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else if(n != c){
            let alert = UIAlertController(title: "Alert!!", message: "Sorry :( Password not matched", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            
            var ind=Int(MyMain.index)
            if(MyMain.pass[ind!]==old.text!){
                MyMain.pass[ind!]=newp.text!
                let alert = UIAlertController(title: "Alert!!", message: "Congrats! Your password has been changed", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                old.text!=""
                newp.text!=""
                confp.text!=""
            }else{
                let alert = UIAlertController(title: "Alert!!", message: "Please enter the right password", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "res.jpg")!)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
